import json,subprocess
from pathlib import Path
root=Path('.audit/engine-rss/observer-cpu');root.mkdir()
for rep in range(1,6):
 for interval in ([0,10] if rep%2 else [10,0]):
  name=f'observer-{rep}-{interval}'
  for mode in ['append','recover']:
   cmd=['python3','scripts/mac-resident-probe.py','target/release/examples/resident_probe',mode,'--records','16384','--group','256','--data',str(root/f'data-{name}'),'--output',str(root/f'{name}-{mode}'),'--interval-ms',str(interval)]
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=150)
   print(name,mode,r.returncode,flush=True)
   if r.returncode:raise RuntimeError(r.stdout+r.stderr)
for label,mode,data,extra in [('empty','empty','.audit/engine-rss/maps-empty-data',[]),('base','recover','.audit/engine-rss/matrix/data-records-1-base',[]),('keys','recover','.audit/engine-rss/matrix/data-keys-1-candidate',['--keys','16384'])]:
 cmd=['python3','scripts/mac-resident-probe.py','target/release/examples/resident_probe',mode,'--records','16384','--group','256','--data',data,'--output',f'.audit/engine-rss/maps/{label}','--maps',*extra]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=150)
 print('maps',label,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
