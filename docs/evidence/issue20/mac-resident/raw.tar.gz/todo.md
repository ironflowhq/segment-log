# Runtime forensics
- [ ] Capture the live signal on the matching surface via the driver skill: a CPU profile for a spinning process, a heap snapshot for a leak, a CDP trace for a visual glitch. A real artifact, not a guess.
- [ ] Reduce the artifact to the smoking gun: the function on the hot path, the retainer chain from the leaked object to a GC root, the loop firing without input. Parse large artifacts in a subagent (the **guard-the-context-window** principle skill), keep the reduced finding in the main thread. Pick each subagent's reasoning level for the job, per the Subagents section.
  skip: subagents prohibited by assignment; root independently reviews.
- [ ] Prove the mechanism before believing it. Inject instrumentation via CDP eval on the running process, or hotfix the live code without reloading, to confirm the hypothesis cheaply.
  Adaptation: diagnostic example and external sampler only; production changes prohibited.
- [ ] Map the finding back to source: file, symbol, the line that allocates or schedules.
- [x] Throughput checkpoint stays one line: `throughput checkpoint: n/a, read-only forensics`.
  Diagnostic extension: one Rust executable and one Python sampler, serial fresh-process trials.
- [ ] Prepare probe; wait for explicit root interval.
- [ ] Run five alternating repetitions; retain failures and raw output.
- [ ] Open focused PR; root independent review remains required.
