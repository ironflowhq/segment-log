import json,subprocess
from pathlib import Path
root=Path('.audit/engine-rss/heap');root.mkdir()
base=(16384,0,1,256,32)
cases={'records':(4096,0,1,64,32),'keys':(16384,16384,1,256,32),'streams':(16384,0,1024,256,32),'groups':(16384,0,1,16,32),'payload':(16384,0,1,256,256)}
for case,candidate in cases.items():
 for rep in range(1,6):
  pair=[('base',base),('candidate',candidate)]
  for side,dims in (pair if rep%2 else pair[::-1]):
   name=f'{case}-{rep}-{side}'
   cmd=['target/release/examples/memory_probe',str(root/'data'),*map(str,dims)]
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
   (root/f'{name}.json').write_text(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2))
   expected=f'validated_records={dims[0]},failures=0,groups={(dims[0]+dims[3]-1)//dims[3]}'
   if r.returncode or r.stdout.splitlines()[-1]!=expected:raise RuntimeError(name)
print('50 requested-heap runs passed')
