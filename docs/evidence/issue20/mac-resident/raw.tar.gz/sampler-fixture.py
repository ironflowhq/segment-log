#!/usr/bin/env python3
import sys
import time

def barrier(name):
    print('barrier\t' + name, flush=True)
    assert sys.stdin.readline().strip() == 'go'

barrier('baseline')
print('begin\ttouch\t' + str(time.time_ns()), flush=True)
buffer = bytearray([165]) * (8 * 1024 * 1024)
print('end\ttouch\t' + str(time.time_ns()) + '\t0', flush=True)
barrier('touched_held')
assert sum(buffer) == 165 * len(buffer)
del buffer
barrier('touched_dropped')
print('result\taccepted=0\tcommitted=0\tadmission_errors=0\tcommit_errors=0\tvalidated=0\tfailures=0', flush=True)
