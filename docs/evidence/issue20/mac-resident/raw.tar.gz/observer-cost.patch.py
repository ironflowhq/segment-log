from pathlib import Path
p=Path('scripts/mac-resident-probe.py')
s=p.read_text()
s=s.replace('ps_ns = 0', 'ps_ns = 0\n        ps_user_s = 0.0\n        ps_system_s = 0.0')
s=s.replace('nonlocal ps_ns', 'nonlocal ps_ns, ps_user_s, ps_system_s')
s=s.replace('start = time.time_ns()\n            observed', 'usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)\n            start = time.time_ns()\n            observed')
s=s.replace('end = time.time_ns()\n            ps_ns', 'end = time.time_ns()\n            usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)\n            ps_user_s += usage_after.ru_utime - usage_before.ru_utime\n            ps_system_s += usage_after.ru_stime - usage_before.ru_stime\n            ps_ns')
s=s.replace("'observer_cpu_s': cpu(start_usage, end_usage),", "'observer_cpu_s': cpu(start_usage, end_usage),\n               'observer_user_s': end_usage.ru_utime - start_usage.ru_utime,\n               'observer_system_s': end_usage.ru_stime - start_usage.ru_stime,\n               'ps_user_s': ps_user_s, 'ps_system_s': ps_system_s,\n               'workload_cpu_s': None if args.maps else cpu(start_children, end_children) - ps_user_s - ps_system_s,")
p.write_text(s)
